/* IMa2  2009-2010  Jody Hey, Rasmus Nielsen and Sang Chul Choi*/
#ifndef _UPDATE_MC_PARAMS_H_
#define _UPDATE_MC_PARAMS_H_

void init_update_mc_params (void);
void free_update_mc_params (void);
#endif /* _UPDATE_MC_PARAMS_H_ */
